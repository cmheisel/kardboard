==========================================
 celery.app.abstract
==========================================

.. contents::
    :local:
.. currentmodule:: celery.app.abstract

.. automodule:: celery.app.abstract
    :members:
    :undoc-members:
