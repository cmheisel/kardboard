def foo():
    ur"""unicode-raw"""

def bar():
    u"""unicode"""

def baz():
    r'raw'

def zap():
    """docstring"""
