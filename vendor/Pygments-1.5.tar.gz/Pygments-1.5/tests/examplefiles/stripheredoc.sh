cat <<-EOF
  Hello world $PATH
  EOF
