/* This file /* which is totally legal scala */ will not be highlighted
   correcty by pygments */

object ⌘ {
  val `interface` = """
A
"Multiline"
String
"""

  val foo_+ = "foo plus"
  val foo_⌬⌬ = "double benzene"

  def main(argv: Array[String]) {
    println(⌘.interface + " " + foo_+ + " " + foo_⌬⌬ )
  }
}

