WTForms is a flexible forms validation and rendering library for python web
development.

For installation instructions, see INSTALL.txt.

To get started using WTForms, we recommend reading the crash course on the
website: http://wtforms.simplecodes.com/.

If you downloaded the package from PyPI, there will be a prebuilt copy of the
html documentation in the `docs/html/` directory. If not, you can
generate it yourself by running `make html` in the `docs` directory.
