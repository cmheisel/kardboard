#: W291
print 
#: W293
class Foo(object):
    
    bang = 12
#: W292
# This line doesn't have a linefeed