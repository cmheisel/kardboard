#: E241
a = (1,  2)
b = (1, 20)
#: E242
a = (1,	2)  # tab before 2
b = (1, 20)  # space before 20
