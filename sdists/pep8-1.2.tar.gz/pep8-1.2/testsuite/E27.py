#: Okay
True and False
#: E271
True and  False
#: E272
True  and False
#: E273
True and		False
#: E274
True		and	False
#: E272
this  and False
#: E274
this		and	False
