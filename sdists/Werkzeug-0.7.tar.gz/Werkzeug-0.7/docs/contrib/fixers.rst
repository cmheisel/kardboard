======
Fixers
======

.. automodule:: werkzeug.contrib.fixers

.. autoclass:: LighttpdCGIRootFix

.. autoclass:: PathInfoFromRequestUriFix

.. autoclass:: ProxyFix

.. autoclass:: HeaderRewriterFix

.. autoclass:: InternetExplorerFix
