=================================
 Celery - Distributed Task Queue
=================================

Contents:

.. toctree::
    :maxdepth: 2

    getting-started/index
    userguide/index

.. toctree::
    :maxdepth: 1

    configuration
    django/index
    cookbook/index
    contributing
    community
    tutorials/index
    faq
    whatsnew-2.5
    changelog
    reference/index
    internals/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

