===============================================
 celery.concurrency.base
===============================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency.base

.. automodule:: celery.concurrency.base
    :members:
    :undoc-members:
