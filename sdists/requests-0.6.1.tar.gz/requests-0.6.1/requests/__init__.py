# -*- coding: utf-8 -*-

from core import *
from core import __version__
