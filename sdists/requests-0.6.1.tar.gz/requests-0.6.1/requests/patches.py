# -*- coding: utf-8 -*-

"""
requests.monkeys
"""
