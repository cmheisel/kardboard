which/which.py -- from http://trentm.com/projects/which/ (MIT license)
