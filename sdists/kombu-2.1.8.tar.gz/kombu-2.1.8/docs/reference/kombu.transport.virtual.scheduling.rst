.. contents::
    :local:
.. currentmodule:: kombu.transport.virtual.scheduling

.. automodule:: kombu.transport.virtual.scheduling
    :members:
    :undoc-members:
