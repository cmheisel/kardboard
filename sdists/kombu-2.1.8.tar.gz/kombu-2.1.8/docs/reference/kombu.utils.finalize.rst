==========================================================
 Finalize - kombu.utils.finalize
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.finalize

.. automodule:: kombu.utils.finalize
    :members:
    :undoc-members:
