from gunicorn.http.errors import NoMoreData
request = NoMoreData